#include <stdint.h>
#include <sys/types.h>
typedef uint64_t crypto_uint64;

#define select ed25519_select
