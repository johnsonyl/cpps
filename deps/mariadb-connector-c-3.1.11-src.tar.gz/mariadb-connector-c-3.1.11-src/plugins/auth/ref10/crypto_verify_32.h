#define crypto_verify_32 crypto_verify
int crypto_verify(const unsigned char *x,const unsigned char *y);
